# 42KL Python Piscine Test Package

This is a simple package excersise. 
it contains 1 funtion that counts items in the list
that matches your what you want to search
1st parameter takes in a list and
2nd parameter takes in a string
