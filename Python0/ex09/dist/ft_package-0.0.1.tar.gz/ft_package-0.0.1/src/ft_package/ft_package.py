def count_in_list(lst: list, word: str) -> int:
    i = 0
    for item in lst:
        if word == item:
            i += 1
    return i